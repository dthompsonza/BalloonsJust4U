<?php
	$pageTitle = 'Blimps & Inflatables';
	$contentPath = 'Blimps_&_Inflatables';
	
	include(dirname(__FILE__).'/../_post.php');
?>