<?php
	$pageTitle = 'Home';

	include('header.php');
?>


<?php
	include('_home.php');
?>

<?php
	include('footer.php');
?>