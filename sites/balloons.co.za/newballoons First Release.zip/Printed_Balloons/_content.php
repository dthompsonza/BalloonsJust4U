    <div class="col-lg-12 xcol-lg-offset-1">
        <div class="panel ">
            <!--<h2 style="text-align: center;"><span xclass="label label-info">Printed Balloons</span></h2>-->
            <div>
                <p>

                    <p style="text-align: left;">Printed balloons can be used for a range of applications from customised parties to large scale corporate events and marketing campaigns.</p>
                    <p style="text-align: left;">Our balloons are printed using specialised ink which ensures dense coverage and sharp, bright colours.</p>
                    <p style="text-align: left;">Printing can be done in one to four colours and from one to four sides.  It should be noted however, that complex logos are difficult to reproduce on balloons and multi-colour prints can sometimes overlap.  The size of printing is also limited.</p>
                    <p style="text-align: left;">The minimum order for printed balloons is 50.</p>
                    <p>&nbsp;</p>
                    <div class="centercontent" style="width: 100%;">
                        <div style="width: 235px" class="wp-caption alignleft">
                            <img class="size-full" src="/Images/Printed/starprint.jpg" alt="" width="225" height="300" />
                            <p class="wp-caption-text">Special Occassions</p>
                        </div>
                        <div style="width: 410px" class="wp-caption alignleft">
                            <img class="size-full" src="/Images/Printed/center.jpg" alt="Logos or Special Occassions" width="400" height="300" />
                            <p class="wp-caption-text">Print in 1 &#8211; 4 colours</p>
                        </div>
                        <div style="width: 235px" class="wp-caption alignleft">
                            <img class="size-full" src="/Images/Printed/corporate.jpg" alt="Corporate Events" width="225" height="300" />
                            <p class="wp-caption-text">Corporate Events</p>
                        </div>
                    </div>
                    <p>
                        <br class="clearleft" />
                        <br />
                        How would you like your balloons printed?
                    </p>
                    <p>
                        <img class="imgleft alignnone wp-image-379" src="/Images/Printed/neckupdown.jpg" alt="neckupneckdown" width="400" height="300" />
                    </p>

                    <br style="clear: left;" />
                </p>
            </div>
        </div>
    </div>
    