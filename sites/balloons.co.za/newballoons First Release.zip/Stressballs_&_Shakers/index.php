<?php
	include(dirname(__FILE__).'/stress.php');
?>