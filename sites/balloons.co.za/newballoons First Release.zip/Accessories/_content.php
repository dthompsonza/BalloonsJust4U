                <div class="col-lg-12 xcol-lg-offset-1">
                                        <div class="panel row-centered">
                        <!--<h2 style="text-align: center;"><span xclass="label label-info">Accessories</span></h2>-->
                        <div >
                            <p>

        						<p style="text-align: left;">We stock a range of balloon accessories and also hire out helium gas cylinders for helium inflation of balloons.</p>
<p style="text-align: left;">For air inflations we sell or hire out electric air inflators.</p>
<p style="text-align: left;">
<p style="text-align: left;">
<p style="text-align: left;">
<div id="attachment_303" style="width: 410px" class="wp-caption alignleft"><img class="size-medium" src="http://www.balloonsjust4u.co.za/wp-content/uploads/2014/07/Helium-Cylinders-300x225.jpg" alt="Helium Cylinders" width="400" height="300" /><p class="wp-caption-text">Helium Cylinders</p></div>
<div id="attachment_304" style="width: 410px" class="wp-caption alignleft"><img class="size-medium" src="http://www.balloonsjust4u.co.za/wp-content/uploads/2014/07/Inflators-300x225.jpg" alt="Electric &amp; Hand Inflators" width="400" height="300" /><p class="wp-caption-text">Electric &amp; Hand Inflators</p></div>
<div id="attachment_344" style="width: 410px" class="wp-caption alignleft"><img class="size-full wp-image-344" src="http://www.balloonsjust4u.co.za/wp-content/uploads/2014/07/balloon_tree1.jpg" alt="Balloon Tree" width="400" height="300" /><p class="wp-caption-text">Balloon Tree</p></div>
<div id="attachment_306" style="width: 410px" class="wp-caption alignleft"><img class="size-medium" src="http://www.balloonsjust4u.co.za/wp-content/uploads/2014/07/Ribbons-and-Balloon-Sticks-300x225.jpg" alt="Ribbons &amp; Balloon Sticks" width="400" height="300" /><p class="wp-caption-text">Ribbons &amp; Balloon Sticks</p></div>
<p><!-- *freelancer*centercontent* --></p>

                                <br style="clear: left;" />
                            </p>
                        </div>
                    </div>
                </div>
