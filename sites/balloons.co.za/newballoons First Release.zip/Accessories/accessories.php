<?php
	$pageTitle = 'Accessories';
	$contentPath = 'Accessories';
	
	include(dirname(__FILE__).'/../_post.php');
?>