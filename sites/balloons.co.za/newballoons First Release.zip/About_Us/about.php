<?php
	$pageTitle = 'About Us';
	$contentPath = 'About_Us';
		
	include(dirname(__FILE__).'/../_post.php');
?>