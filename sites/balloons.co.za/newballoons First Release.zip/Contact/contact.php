<?php
	$pageTitle = 'Contact';
	$contentPath = 'Contact';
		
	include(dirname(__FILE__).'/../_post.php');
?>