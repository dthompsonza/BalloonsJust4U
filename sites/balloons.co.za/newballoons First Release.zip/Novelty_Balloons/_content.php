    <div class="panel ">
        <!--<h2 style="text-align: center;"><span xclass="label label-info">Novelty Balloons</span></h2>-->
        <div>
            <p>

                <p><strong>Standard Print Balloons</strong></p>
                <p>&nbsp;</p>
                <div style="width: 310px" class="wp-caption alignleft">
                    <img class="size-medium" src="/images/Novelty/allround.jpg" alt="x_balloonprint2" width="300" height="225" />
                    <p class="wp-caption-text">All-rounded print</p>
                </div>
                <div style="width: 310px" class="wp-caption alignleft">
                    <img class="size-medium" src="/Images/Novelty/14print.jpg" alt="x_balloonprint" width="300" height="225" />
                    <p class="wp-caption-text">1 &#8211; 4 sided print</p>
                </div>
                <p>&nbsp;</p>
                <p>
                    <br class="clearleft" /><br />
                    <center>
                        <strong>​Available prints in 1-4 sides or all-rounded print</strong>
                    </center>
                    <br />
                    <img class="alignleft size-full" src="/Images/Novelty/prints1.jpg" width="450" height="554" />
                    <img class="alignleft size-full" src="/Images/Novelty/prints2.jpg" width="450" height="609" />
                </p>
                <p>
                    <br class="clearleft" /><br />
                    <strong>Printed balloons for special occasions:</strong>
                </p>
                <ul>
                    <li>Birthdays</li>
                    <li>Weddings</li>
                    <li>Easter</li>
                    <li>Christmas</li>
                    <li>Mothers Day</li>
                    <li>Fathers Day</li>
                    <li>Valentines Day</li>
                    <li>&amp; many more&#8230;</li>
                </ul>
                <p>
                    <br class="clearleft" />
                    <br />

                    <strong>Shaped Balloons</strong>
                </p>
                <p>&nbsp;</p>
                <div style="width: 310px" class="wp-caption alignleft">
                    <img class="size-medium" src="/Images/Novelty/modelling.jpg" alt="Modelling balloons" width="300" height="225" />
                    <p class="wp-caption-text">Modelling balloons</p>
                </div>
                <div style="width: 310px" class="wp-caption alignleft">
                    <img class="size-medium" src="/Images/Novelty/animal.jpg" alt="Animal shaped balloons" width="300" height="225" />
                    <p class="wp-caption-text">Animal shaped balloons</p>
                </div>
                <div style="width: 310px" class="wp-caption alignleft">
                    <img class="size-medium" src="/Images/Novelty/heart.jpg" alt="Heart shaped balloons" width="300" height="225" />
                    <p class="wp-caption-text">Heart shaped balloons</p>
                </div>

                <br style="clear: left;" />
            </p>
        </div>
    </div>
