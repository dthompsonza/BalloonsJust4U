<?php
	$pageTitle = 'Plain Balloons';
	$contentPath = 'Plain_Balloons';
	
	include(dirname(__FILE__).'/../_post.php');
?>