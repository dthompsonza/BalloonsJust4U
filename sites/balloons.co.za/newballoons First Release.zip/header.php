<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="description" content="balloon supplies, printing and decorating, helium, latex, party balloons" />
    <meta name="author" content="David Thompson & Balloons Just 4 U">

    <title> <?php 
                $thisPageTitle = $pageTitle;
                if (strlen($thisPageTitle) > 0)
                    $thisPageTitle = $thisPageTitle . ' | ';
                echo $thisPageTitle; 
            ?> Balloons Just 4 U</title>

    <!-- Fonts -->

    <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

    <!-- IE8 support for HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    

    <link href="/_inc/css/bootstrap.css" rel="stylesheet">
    <link href="/_inc/css/freelancer.css" rel="stylesheet">
    <link href="/_inc/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="/_inc/css/ribbon.css" rel="stylesheet">

    <link href="/style.css" rel="stylesheet">

    <?php include(dirname(__FILE__).'/_google/analytics.php'); ?>

</head>

<body id="page-top" class="index">

    <!-- Navigation -->
    <nav class="navbar navbar-default xnavbar-fixed-top">

        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#page-top">
                    <img src="/_inc/custom/logo.png" class="visible-lg visible-md" />
                    <img src="/_inc/custom/logosm.png" class="visible-sm visible-xs" />
                </a> 
            
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->

            
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            
                <div id="bs-example-navbar-collapse-1" class="menu-primary-menu-container">
                    <ul id="menu-primary-menu" class="nav navbar-nav navbar-right">
                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home <?php echo ($pageTitle=='Home') ? 'active' : '' ;?>">
                            <a title="Home" href="/">Home</a>
                        </li>
                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children dropdown">
                            <a title="Our Products" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Our Products <span class="caret"></span></a>
                            <ul role="menu" class=" dropdown-menu">
                                <li class="menu-item menu-item-type-custom menu-item-object-custom  <?php echo ($pageTitle=='Plain Balloons') ? 'active' : '' ;?>">
                                    <a title="Plain Balloons" href="/Plain_Balloons">Plain Balloons</a></li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom  <?php echo ($pageTitle=='Printed Balloons') ? 'active' : '' ;?>">
                                    <a title="Printed Balloons" href="/Printed_Balloons">Printed Balloons</a></li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom  <?php echo ($pageTitle=='Novelty Balloons') ? 'active' : '' ;?>">
                                    <a title="Novelty Balloons" href="/Novelty_Balloons">Novelty Balloons</a></li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom  <?php echo ($pageTitle=='Decorating') ? 'active' : '' ;?>">
                                    <a title="Decorating" href="/Decorating">Decorating</a></li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom  <?php echo ($pageTitle=='Accessories') ? 'active' : '' ; //current-menu-item ?>">
                                    <a title="Accessories" href="/Accessories">Accessories</a></li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom  <?php echo ($pageTitle=='Blimps & Inflatables') ? 'active' : '' ;?>">
                                    <a title="Blimps &amp; Inflatables" href="/Blimps_&_Inflatables">Blimps &#038; Inflatables</a></li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom  <?php echo ($pageTitle=='Stressballs & Shakers') ? 'active' : '' ;?>">
                                    <a title="Stressballs &amp; Shakers" href="/Stressballs_&_Shakers">Stressballs &#038; Shakers</a></li>
                            </ul>
                        </li>
                        <li class="menu-item menu-item-type-post_type menu-item-object-page <?php echo ($pageTitle=='About Us') ? 'active' : '' ;?>">
                            <a title="About Us" href="/About_Us">About Us</a>
                        </li>
                        <li class="menu-item menu-item-type-post_type menu-item-object-page <?php echo ($pageTitle=='Contact') ? 'active' : '' ;?>">
                            <a title="Contact" href="/Contact">Contact</a>
                        </li>
                    </ul>
                </div>               



               
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>


    

    <div class="ballooncontent container">

<!-- end of header.php -->