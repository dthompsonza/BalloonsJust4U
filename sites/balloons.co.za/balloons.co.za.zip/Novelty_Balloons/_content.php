    <div class="panel ">
        <!--<h2 style="text-align: center;"><span xclass="label label-info">Novelty Balloons</span></h2>-->
        <div>
            <p>

                
                <p><strong>Standard Print Balloons</strong></p>
                <center>
                    

                    <table class="text-center" sxtyle="width: 100%; background-color: #aaaa00;" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td class="text-right">
                                <img src="/Images/Novelty/allround.jpg" class="img-responsive" />
                                <p class="wp-caption-text">All-rounded print</p>
                            </td>
                            <td>&nbsp;&nbsp;&nbsp;</td>
                            <td class="text-left">
                                <img src="/Images/Novelty/14print.jpg" class="img-responsive" />
                                <p class="wp-caption-text">1 &#8211; 4 sided print</p>
                            </td>
                        </tr>
                    </table>
                </center>
                    


               <br/>

                <center>
                    <p><b>​Available prints in 1-4 sides or all-rounded print</b></p>
                    
                    <table class="text-center" sxtyle="width: 100%; background-color: #aaaa00;" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td class="text-right">
                                <img class="img-responsive" src="/Images/Novelty/prints1.jpg?a=1" width="450" height="609" />
                            </td>
                            <td>&nbsp;&nbsp;&nbsp;</td>
                            <td class="text-left">
                                <img class="img-responsive" src="/Images/Novelty/prints2.jpg" width="450" height="609" />
                            </td>
                        </tr>
                    </table>
                </center>


                <p>
                    <br />
                    <center>
                        <b>Printed balloons for special occasions:</b>
                    </center>
                </p>
                
                <center>
                    <table xclass="text-center" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td>
                                <ul>
                                    <li>Birthdays</li>
                                    <li>Weddings</li>
                                    <li>Easter</li>
                                    <li>Christmas</li>
                                    <li>Mothers Day</li>
                                    <li>Fathers Day</li>
                                    <li>Valentines Day</li>
                                    <li>&amp; many more&#8230;</li>
                                </ul>
                            </td>
                        </tr>
                    </table>
                </center>
                

        
                <p>&nbsp;</p>

                <p><strong>Shaped Balloons</strong></p>

                <center>
                    

                    <table style="width: 100%;" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td>
                                <center>
                                    <img src="/Images/Novelty/modelling.jpg" class="img-responsive"/>
                                    <p class="wp-caption-text">Modelling balloons</p>
                                </center>
                            </td>
                            <td>
                                <center>
                                    <img src="/Images/Novelty/animal.jpg" class="img-responsive"/>
                                    <p class="wp-caption-text">Animal shaped balloons</p>
                                </center>
                            </td>
                            <td>
                                <center>
                                    <img src="/Images/Novelty/heart.jpg" class="img-responsive"/>
                                    <p class="wp-caption-text">Heart shaped balloons</p>
                                </center>
                            </td>
                        </tr>
                    </table>
                </center>

            </p>
        </div>
    </div>
