<?php
	include(dirname(__FILE__).'/contact.php');
?>