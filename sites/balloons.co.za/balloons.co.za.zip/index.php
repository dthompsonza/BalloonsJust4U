<?php
	$pageTitle = '';

	include('header.php');
?>


<?php
	include('_home.php');
?>

<?php
	include('footer.php');
?>