
    <div class="col-lg-12 xcol-lg-offset-1">
        <div class="panel ">
            <!--<h2 style="text-align: center;"><span xclass="label label-info">Stressballs &#038; Shakers</span></h2>-->
            <div>
                <p>
                    <p>
                        <strong>Stressballs</strong>
                    </p>
                    <p>
                        <img class="imgleft size-medium" src="/Images/Stressballs/stress.jpg" />
                    </p>
                    <p>
                        Stressballs are great for promotional giveaways and can be produced with corporate logos in 1-4 colours.
                    </p>
                    <br style="clear: left;" />
                    <p>&nbsp;</p>
                    <p>
                        <strong>Cold Air Inflatables</strong>
                    </p>
                    <p>
                        <img class="alignleft size-medium" src="/Images/Stressballs/shaker.jpg?a=1"/>
                        Shakers can be branded with logos, inflated or deflated for multiple use and are superb for sporting events.
                    </p>

                   
                    

                    <br style="clear: left;" />
                </p>
            </div>
        </div>
    </div>

