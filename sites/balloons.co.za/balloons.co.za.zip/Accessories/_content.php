                <div class="col-lg-12 xcol-lg-offset-1">
                                        <div class="panel row-centered">
                        <!--<h2 style="text-align: center;"><span xclass="label label-info">Accessories</span></h2>-->
                        <div >
                            <p>

        						<p style="text-align: left;">
                                    We stock a range of balloon accessories and also hire out helium gas cylinders for helium inflation of balloons.
                                </p>
                                <p style="text-align: left;">For air inflations we sell or hire out electric air inflators.</p>
                                <p style="text-align: left;">
                                <p style="text-align: left;">
                                <p style="text-align: left;">

                                <table style="width: 100%;" cellpadding="0" cellspacing="0" border="0">
                                    <tr>
                                        <td class="text-center">
                                            <img class="img-responsive flcenter" src="/Images/Accessories/cylinders.jpg" />
                                            <p class="wp-caption-text">Helium Cylinders</p>
                                        </td>
                                        <td class="text-center">
                                            <img class="img-responsive flcenter" src="/Images/Accessories/inflators.jpg"/>
                                            <p class="wp-caption-text">Electric &amp; Hand Inflators</p>
                                        </td>
                                    </tr>   
                                    <tr>
                                        <td class="text-center">
                                            <img class="img-responsive flcenter" src="/Images/Accessories/tree.jpg"/>
                                            <p class="wp-caption-text">Balloon Tree</p>
                                        </td>
                                        <td class="text-center">
                                            <img class="img-responsive flcenter" src="/Images/Accessories/ribbon.jpg"/>
                                            <p class="wp-caption-text">Ribbons &amp; Balloon sticks</p>
                                        </td>
                                    </tr>   
                                </table>

                                
                            </p>
                        </div>
                    </div>
                </div>
