<?php
	$pageTitle = 'Stressballs & Shakers';
	$contentPath = 'Stressballs_&_Shakers';
	
	include(dirname(__FILE__).'/../_post.php');
?>