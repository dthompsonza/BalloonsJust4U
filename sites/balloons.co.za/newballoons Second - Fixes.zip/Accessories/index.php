<?php
	include(dirname(__FILE__).'/accessories.php');
?>