    <div class="col-lg-12 xcol-lg-offset-1">
        <div class="panel ">
            <!--<h2 style="text-align: center;"><span xclass="label label-info">Blimps &#038; Cold Air Inflatables</span></h2>-->
            <div>
                <p>

                    <p>
                        <strong>Blimps</strong>
                    </p>
                    <p>
                        <img class="size-medium imgleft" src="/Images/Blimps/blimp.jpg" alt="blimp1_big" width="300" height="225" />
                    </p>
                    <p>
                        Customised blimps that require helium inflation are a great way to promote your brand at outdoor events.  
                        They float up to 50 meters high and once inflated last a week or more.  Their use however, is weather dependent.
                    </p>
                    <br style="clear: left;" />
                    <p>&nbsp;</p>
                    <p>
                        <strong>Cold Air Inflatables</strong>
                    </p>
                    <p>
                        <img class="size-medium imgleft" src="/Images/Blimps/inflatable.jpg" alt="Custom Cold Air Inflatables" width="300" height="225" /> 
                        Customised cold air inflatables are fan driven and remain on the ground.  
                        Sealed inflatables can also be used that do not require a fan and are smaller in size.
                    </p>

                    <br style="clear: left;" />
                </p>
            </div>
        </div>
    </div>