<?php
	include(dirname(__FILE__).'/blimps.php');
?>