<?php
	include(dirname(__FILE__).'/novelty.php');
?>