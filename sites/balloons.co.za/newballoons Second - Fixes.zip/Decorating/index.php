<?php
	include(dirname(__FILE__).'/decorating.php');
?>