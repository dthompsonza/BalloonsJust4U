<?php
	$pageTitle = 'Decorating';
	$contentPath = 'Decorating';
	
	include(dirname(__FILE__).'/../_post.php');
?>