    <div class="panel ">
                        <!--<h2 style="text-align: center;"><span xclass="label label-info">About Us</span></h2>-->
                        <div >
                            <p>

                                <p>We are specialists in the supply of <b>printed &amp; plain helium quality latex balloons</b>, related balloon accessories and décor nationwide.</p>
								<p>&nbsp;</p>
								<p>We specialize in the following:</p>
								<ul>
									<li>Balloon Printing</li>
									<li>Balloon Decorating</li>
									<li>Helium Balloons</li>
									<li>Helium Gas</li>
									<li>Balloon Accessories</li>
									<li>Balloon Drops</li>
									<li>Balloon Releases</li>
									<li>Modelling Balloons</li>
									<li>Giant Balloons</li>
									<li>Stress Balls</li>
									<li>Shakers</li>
									<li>Cold Air Inflatables</li>
									<li>Advertising Blimps</li>
								</ul>
								<p>&nbsp;</p>
								<p>The company was established in 1987 and has based its success on the personal involvement of its owners to ensure all aspects of its business are carried out professionally and to the highest standard.</p>
								<p>We have partners nationwide who are experienced and pay attention to detail to ensure customer satisfaction on all decorating work.</p>
								<p>All our balloons are high quality latex suitable for helium use.  Latex comes from the rubber tree and is 100% biodegradable.</p>
								<p>&nbsp;</p>
								<h4>&#8220;Balloons are our business!!!&#8221;</h4>
								<p>&nbsp;</p>
								<p>
									<img class="alignleft wp-image-290" src="http://www.balloonsjust4u.co.za/wp-content/uploads/2014/06/Biodegradable.png" alt="Biodegradable" width="100" height="100" />
									<img class="alignleft wp-image-57" src="http://www.balloonsjust4u.co.za/wp-content/uploads/2014/06/bee.png" alt="BEE" width="102" height="100" />
								</p>

                                <br style="clear: left;" />
                            </p>
                        </div>
                    </div>
