<?php
	include(dirname(__FILE__).'/plain.php');
?>