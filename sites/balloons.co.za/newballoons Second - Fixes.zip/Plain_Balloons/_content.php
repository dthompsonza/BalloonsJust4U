
    <div class="col-lg-12 xcol-lg-offset-1">
        <div class="panel">
            <!--<h2 style="text-align: center;"><span xclass="label label-info">Plain Balloons</span></h2>-->
        <div >
        <p>
            <div class="text-left">
                <p style="text-align: center;">Choose from our wide range of plain coloured balloons in a variety of sizes and colours.</p>
                <p style="text-align: center;">Our standard sizes are 9&#8243; (27.5cm), 11&#8243; (30cm) and 12&#8243; (35cm) balloons.  Metallic balloons only come in 12&#8243; size.</p>
                <p style="text-align: center;">In addition to these standard sizes we also stock smaller and larger sizes for specific applications.</p>
                <p style="text-align: center;">We carry a wide range of stock however, for larger orders or specific sizes, supply will be subject to availability.</p>
            </div>
            <p>&nbsp;</p>
            <center>
                <p><strong>Standard Colours</strong></p>
                <div class="whitegroup">
                    <img class="alignnone" src="/Images/Plain/l1.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/l2.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/l3.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/l4.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/l5.jpg" alt="" />
                </div>
                <p>&nbsp;</p>
                <p><strong>Pastel Colours</strong></p>
                <div class="whitegroup">
                    <img class="alignnone" src="/Images/Plain/p1.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/p2.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/p3.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/p4.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/p5.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/p6.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/p7.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/p8.jpg" alt="" />
                </div>
                <p>&nbsp;</p>
                <p><strong> Metallic Colours</strong></p>
                <div class="whitegroup">
                    <img class="alignnone" src="/Images/Plain/m1.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m2.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m3.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m4.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m5.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m6.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m7.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m8.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/m9.jpg" alt="" />
                </div>
                <p>&nbsp;</p>
                <p><strong>Giant Balloon Sizes</strong></p>
                <div class="whitegroup">
                    <img class="alignnone" src="/Images/Plain/g1.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/g2.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/g3.jpg" alt="" />
                    <img class="alignnone" src="/Images/Plain/g4.jpg" alt="" />
                </div>
            </center>
            <p>&nbsp;</p>
            <p>All of our balloons are 100% biodegradable.</p>
            <p>

                <img class="alignnone size-full" src="/Images/Misc/bio.png" alt="" width="100" height="100" />
                
            </p>

            <br style="clear: left;" />
        </p>
    </div>

